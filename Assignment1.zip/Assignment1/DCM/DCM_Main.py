from DCM_WelcomeScreen import openWelcome

openWelcome()
